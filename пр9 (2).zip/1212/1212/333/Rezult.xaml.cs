﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _333
{
    /// <summary>
    /// Логика взаимодействия для Rezult.xaml
    /// </summary>
    public partial class Rezult : Window
    {
        public Rezult()
        {
            InitializeComponent();
        }

        private void btnListFromFile_Click(object sender, RoutedEventArgs e)
        {
            try //обработка исключения
            {
                //Получаем номер выделенной строки 
                int index = lstinput.SelectedIndex;
                //Считываем строку в переменную str
                string str = (string)lstinput.Items[index];
                //Узнаем количество символов в строке
                int len = str.Length;
                //Считаем, что количество пробелов ровно 0
                int count = 0;
                //Устанавливаем счетчик символов в 0
                int i = 0;
                //Организуем цикл перебора всех символов в строке
                while (i < len - 1)
                {
                    //Если нашли пробел, то увеличиваем
                    // счетчик пробелов на 1
                    if (str[i] == ' ')
                        count++;
                    i++;
                }
                txbRezult.Text = "Количество пробелов =" + count.ToString();
            }
            catch (Exception ex) // "поймать" ошибку
            {
                MessageBox.Show(ex.Message);//вывести сообщение об ошибке


                /// <summary>
                /// считывание строк текста их файла
                /// </summary>
                /// <parm name="e"></parm>

                private void btnListFromFile_Click(object sender, RoutedEventArgs e)
                {
                    StreamReader sr = new StreamReader(@"Строки.txt", Encoding.UTF8);

                    while (!sr.EndOfStream)
                    {
                        lstinput.Items.Add(sr.Readline());
                    }

                }
            }
        }
              
                

